<?php 
define('ru','ru');     //ru
define('ee','ee');    //  эстонская
define ('lv','lv');   //латвийский
define ('lt','lt');   //литовский
define('md','md');    //молдавская
define('ua','ua');    // Украинская
define ('by','by');   //беларуский
define ('ge','ge');   //грузинский
define ('ar','ar');   //
define ('az','az');   //
define ('kr','kr');   //киргизская
define('uz','uz');    // узбекская
define('kz','kz');    //казахская
define ('td','td');   // таджикская
define ('tm','tm');   // туркменская
define('cn','cn');    // татарский
define('cz','cz');
define('de','de');
define('it','it');
define('fr','fr');
define('tk','tk');
define('en','en');
define('jp','jp');
define('vn','vn');
define("tu",'tu'); 
//--------------const default-------------------------------|
define ('DEFAULT_LANG',                                cz);
  $langs= array(ru,ua,cz, en, kz,ge,lv,lt,uz, it, jp, cn,tk,fr, vn);                           // array_intersect(array array1, array array2, [array ...])
  $lang_title=array(
                   ua => 'український',
                   lt => 'Litva',
                   lv => 'Latvia',
                   uz => 'Uzbekistan',
                   ru => 'Русский',
                   ge => 'ქართული',
                   by => 'беларусский',
                   en => 'English',
                   de => 'Deutch',
                   cn => 'China',
                   cz => 'Česky',
                   ee => 'Estony',
                   it => 'Italian',
                   fr => 'France',
                   jp => 'Japan',
                   vn => 'Vietnam',
                   tu => 'Turkmenistan',
                   tk => 'Tadgikistan',
                   kz => 'Қазақша'
 );
//if(array_key_exists('lng', $_REQUEST)&&(strlen($_REQUEST['lng']>=2))&&(@sizeof( @array_intersect($langs, $_REQUEST)==1))) {$lng= $_REQUEST['lng']; }else{ $lng=ru;} //        array_key_exists(mixed key, array search)



////////////////////////////////////////////// 
$lng = (array_key_exists('lng' , $_REQUEST))? $_REQUEST['lng']:DEFAULT_LANG; 
$r='<div style="margin-top:0px">';
if(array_key_exists("show_lang_panel",$_REQUEST)) { 
 foreach($langs as $key=>$value){
    $r .=  '<a href="?lng='.$value.'"><img src="flags/'.$value.'.png" class="flags"   title ="' .
           $lang_title[$value].'"></a>&nbsp;';
    }

 } else{
  $r.='<a href="?lng='. $lng .'&amp;show_lang_panel=1">
          <img src="./flags/'. $lng.'.png" class="flags"  title ="Current language is ' .$lang_title[$lng].'.  Click to change language  ">
       </a>';
 }

 $r .='</div>';    
    echo ($r);

 ////////////////////////////////
 
 ?>



