<?php

$lng=$_REQUEST['lng'];
$text=file("readme/ReadMe_" . $lng .".txt");
array_unshift($text, "[".$lng."]");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <title><?php echo($text[1])?></title>
  <link rel="stylesheet" href="assets/style/style.css" type="text/css" media="screen" />
  
</head>
<body>
    <h2><?php echo($text[2])?></h2>
     <b><?php echo($text[3])?></b><br>
        <?php echo($text[4])?><br>
        <?php echo($text[5])?><br>
<br>
<strong><?php echo($text[6])?></strong><br>
        <?php echo($text[7])?><br>
        <?php echo($text[8])?><br>
        <?php echo($text[9])?><br>
        <?php echo($text[10])?><br>
<br>
<strong><?php echo($text[11])?><br></strong>
        <?php echo($text[12])?><br>
        <?php echo($text[13])?><br>
        <?php echo($text[14])?><br>
        <?php echo($text[15])?><br>
        <?php echo($text[16])?><br>
        <?php echo($text[17])?><br>
<br>
<strong><?php echo($text[18])?></strong>
        <?php echo($text[19])?>
<strong><?php echo($text[20])?></strong>
        <?php echo($text[21])?><br>
        <?php echo($text[22])?><br>
        <?php echo($text[23])?>
<strong><?php echo($text[24])?></strong> 
<br><br><br>
<div class="message">
        <?php echo($text[33])?><br>
        <?php echo($text[34])?></div><br>
<br>
<strong><?php echo($text[25])?></strong><br>
        <?php echo($text[26])?><br>
        <?php echo($text[27])?><br>
        <?php echo($text[28])?><br>
        <?php echo($text[29])?><br>
        <?php echo($text[30])?><br>
        <?php echo($text[31])?><br>
        <?php echo($text[32])?><br>
    <br>
</body>
</html>
