<?php
$links = array(
          
 );
?>
<div class="container">
    <div class = "row">
        <div class = "navigator">
            <div class ="logo ">
                <!-- insert here your logo  --><h1>
                    <?php echo($labels[1]) ?></h1><h4>
                    <?php echo($labels[2]) ?></h4>
            </div>
            <div class = "navigator">
                            <!-- insert lang_panel  -->
                <?php echo ($lang_panel); ?>

                <ul>
                  
           <li> <a href="#" title="<?php echo($labels[6]) ?>" ><?php echo($labels[3]) ?></a></li>
           <li> <a href="#" title="<?php echo($labels[6]) ?>" ><?php echo($labels[4]) ?></a></li>
           <li> <a href="ReadMe.html" title="<?php echo($labels[6]) ?>" ><?php echo($labels[5]) ?></a></li>
           <li> <a href="ReadMe.php?lng=<?php echo($lng)?>"  title="<?php echo($labels[11]) ?>" ><?php echo($labels[11]) ?></a></li>                                     
                </ul>
            <button class="btn1" type= "submit">
            <a href="#" title="<?php echo($labels[7]) ?>" ><?php echo($labels[7]) ?></a>
            </button>
            
            </div>
        </div>
    </div>
</div>
