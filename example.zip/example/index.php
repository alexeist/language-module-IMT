<?php
//$lng                 = DEFAULT_LANGUEAGE;


//------------- connect the libraries
include_once("lang_panel.php");
check_available_lang(PATH_TO_LANGUAGES . DIRECTORY_SEPARATOR . $lng . DB_FILES_EXTENSION);
$labels = file(PATH_TO_LANGUAGES . DIRECTORY_SEPARATOR . $lng . DB_FILES_EXTENSION);
array_unshift($labels, "[". $lang_title[$lng] . "]");
$title = $labels[1];                                              // the title of site must be in the first line in the data base file
?>


<!DOCTYPE HTML">
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title><?php print($title)?></title>
  <link rel="stylesheet" href="assets/style/style.css" type="text/css" media="screen" />
  </head>
  <body>  
<?php
   include_once("menu_up.php");
?>
<div class="container">
<div class="row">
<!-- TO DO -->
<center>
<h2><?php echo($labels[8])?></h4>
<p><?php echo($labels[9])?></p>
<p><?php echo($labels[10])?></p>
 </center>

</div></div> 
</body>
</html>
 



  

