Read Me English
This file explain How to use the language panel package...
1 Requirement:
 1.1 HTTP-server like Appache 
  1.2 PHP server version 5.xx and later
2 Installation
 2.1 Install this script into your site like it is in this example - 'index.php'
 2.2 create the default language list in the file 'languages/en.txt', where place every label you need to translate into other language
 2.3 edit the array $langs and place there all available languages,  variable locates in the file 'lang_panel.php'. 
 2.4 edit the array $lang_title and add need language names,  variable locates in the file 'lang_panel.php'.
3 First start program
 3.1 Start programm.
  3.1.1 Only one current language flag will be show.
  3.1.2 Full gallery of languages flags is hidden until the user click on a current language flag.
  3.2 Click on a current language flag the full avalabel language flags will appear.
  3.3 Clickw on selected language flag will change the Global variable $lng to new language value. And page will relaoad with hidden glag gallery and show new language flag only.
  3.4 If file with name '&lt;language code&gt;.txt' do not exists the script automatically creates the copy of default language file with new language name and shows the message about it.
4 click every language-flag
you add. In result the script 
 automatically
 creates the full complete of the files translate to. Every new files will have the same text like the default language list in default language file (usually en.txt). 
 4.1 After you have all files for translate labels from default language you can copy sequently copy the text from appropriate file '&lt;language code&gt;.txt' and sent it to translatlor.
4.2 Insert in the new language file the translated text 
STRONGLY INTO THE SAME NUMBERS OF ROW
5 What to do if...
 5.1 What to do if in the selected new language the labels show incorrect?
   Answer:
   5.1.1  Check the numbers of translated words. The every translated word must be locate strongly in the same rows like in the default language file
 5.2 What to do if  every languages labels placed incorrect?
   Answer:
   5.1.2 Check the numbers of rows in the default language file (usually  'language/en.txt') and bring that into line with the php script uses it.
   5.1.3 After the default language will show correct labels edit all other languages files to harmonize that with default language file; 
       IMPORTANT NOTE: The translated text must be locates strongly in the SAME ROWS like in the default language file. 
Therefore for control it you must to use the editor with show string numberes.                                 